package com.example.mobileproggpsapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

public class Getlocation implements LocationListener {
    Context context;

    public Getlocation(Context c){
        context = c;
    }

    public Location getlocation{}{
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(context, "Permission not granted", Toast.LENGTH_SHORT).show();
            return null;
        }

        LocationManager locationManager =(LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        Boolean isGpsEnabled = locationManager.isProviderEnabled(locationManager.GPS_PROVIDER);
        Boolean isNetworkEnabled = locationManager.isProviderEnabled(locationManager.NETWORK_PROVIDER);

        if (isNetworkEnabled){
            locationManager.requestLocationUpdates(locationManager.NETWORK_PROVIDER, minTime: 1000, minDistance, listener: this);
            Location locationNetwork = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
            return locationNetwork;

        }else if (isGpsEnabled){
            locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, minTime: 1000, minDistance, listener: this);
            Location location = locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
            return location;
        }else{
            Toast.makeText(context, "Please Enabled GPS", Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }
}
