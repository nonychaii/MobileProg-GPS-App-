package com.example.mobileproggpsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView lokasisayakini, value;
    EditText latitude, longtitude;
    Button hitungjarak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, requestCode: 0);


        lokasisayakini = (TextView) findViewById(R.id.txt_lokasisayakini);
        value = (TextView) findViewById(R.id.txt_value);
        latitude = (EditText) findViewById(R.id.edt_latitude);
        longtitude = (EditText) findViewById(R.id.edt_longtitude);
        hitungjarak = (Button) findViewById(R.id.btn_hitungjarak);

        hitungjarak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Getlocation getlocation = new Getlocation(getApplicationContext());
                Location location = getlocation.getlocation();
                if (location !=null){
                    double latitudeSaya = location.getLatitude();
                    double longtitudeSaya = location.getLongitude();
                    double latitudeTujuan = Double.valueOf(latitude.getText().toString());
                    double longtitudeTujuan = Double.valueOf(longtitude.getText().toString());

                    lokasisayakini.setText(latitudeSaya + "," + longtitudeSaya);
                    double jarak = getlocation(latitudeTujuan, longtitudeTujuan, latitudeSaya, longtitudeSaya);
                    value.setText(jarak + "meter");
                    }
                }
            }
        });

    }
    private getDistance(Double latitudeTujuan, Double longtitudeTujuan, Double latitudeUser, Double longtitudeUser){
        /* untuk variable */
        Double pi = 3.14159265358979;
        Double lat1 = latitudeTujuan;
        Double lon1 = longtitudeTujuan;
        Double lat2 = latitudeUser;
        Double lon2 = longtitudeUser;
        Double R = 6371e3;

        Double latRad1 = lat1 * (pi/180);
        Double latRad2 = lat2 *(pi/180);
        Double deltalatRad = (lat2 - lat1) * (pi/180);
        Double deltalonRad = (lon2 - lon1) * (pi/180);

        /*rumusnya pake haversine*/
        Double a= Math.sin(deltalatRad / 2) * Math.sin(deltalatRad/2) + Math.cos(latRad1)*Math.cos(latRad2)* Math.sin(deltalonRad/2) * Math.sin(deltalonRad/2);
        Double c = Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
        Double s = R * c; // hasilnya jarak itu dalam meter
        return s;

    }
}